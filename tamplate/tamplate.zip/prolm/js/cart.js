 function commaSeparateNumber(val){
    while (/(\d+)(\d{3})/.test(val.toString())){
      val = val.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1 ");
    }
    return val;
  }
function addGoodsToCart(form) {
	if($('.lvhue span').text()=="Вход"){
		$("html,body").animate({"scrollTop":0},"slow");
		setTimeout(function() { $('.enter_b').fadeIn();	$(this).addClass('open');}, 500);
		
	} else {
	
	
		var req = new JsHttpRequest();
		req.onreadystatechange = function() {
			if (req.readyState == 4) {
				if (req.responseJS) {

					 //   alert('Товар добавлен в Вашу корзину');
						$('.basket_add p').html(req.responseJS.total+' товар(ов) <br/> '+commaSeparateNumber(req.responseJS.cost)+"&nbsp;"+req.responseJS.currency);
						
						var modal_div = $('.modal');
						modal_div.find('.summary').empty().html('В корзине <span>'+req.responseJS.total+' товар(ов)</span><br>на сумму <span>'+commaSeparateNumber(req.responseJS.cost)+'</span> '+req.responseJS.currency);
						modal_div.css('top',modal_div.innerHeight()*(-1)+'px');
						modal_div.show().animate({
							top: '45%'
						},500).addClass('opened');
						
						if(modal_div.hasClass('opened')){
							modal_div.removeClass('opened');
							setTimeout(function(){$('.close_modal').trigger('click');},5000);
						}
					
				}
			}
		};
		req.open("POST", form.action, true);
		req.send( form );
		var bl = document.getElementById("blckLoading");
		if (! bl) {
			bl = document.createElement('div');
			bl.id = 'blckLoading';
		//    bl.appendChild(document.createTextNode('Загрузка ...'));
			document.body.appendChild(bl);
		}
		bl.style.display = 'block';
		return false;
	}
}

function requestPrice(form) {
	if($('.lvhue span').text()=="Вход"){
		$("html,body").animate({"scrollTop":0},"slow");
		setTimeout(function() { $('.enter_b').fadeIn();	$(this).addClass('open');}, 500);
	} else {
		var req = new JsHttpRequest();
		req.onreadystatechange = function() {
			if (req.readyState == 4) {
				if (req.responseJS) {
					    alert('Запрос цены на '+req.responseJS.title+' в количестве '+req.responseJS.quantity+' '+req.responseJS.edinica+' отправлен. В ближайшее время мы дадим Вам ответ.');
				}
			}
		};
		req.open("POST", form.action, true);
		req.send( form );
		return false;
	}
}