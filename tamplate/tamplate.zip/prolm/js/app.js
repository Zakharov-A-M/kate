$(function () {

    if (window.PIE) {
        $('.ie-pie').each(function () {
            PIE.attach(this);
        });
    }
    ;

    if (!Modernizr.input.placeholder) {
        $('[placeholder]').focus(function () {
            var input = $(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function () {
            var input = $(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur();
        $('[placeholder]').parents('form').submit(function () {
            $(this).find('[placeholder]').each(function () {
                var input = $(this);
                if (input.val() == input.attr('placeholder')) {
                    input.val('');
                }
            })
        });
    }
    ;

    // для стилизации элементов с .styler   http://dimox.name/jquery-form-styler/
    $('input, select').styler();

    $('.lvhue span').click(function () {
        if ($(this).hasClass('open')) {
            $('.enter_b').fadeOut();
            $(this).removeClass('open')
        } else {
            $('.enter_b').fadeIn();
            $(this).addClass('open');
        }
    });

    $(document).click(function (e) {
        var u = 0;
        if ($(e.target).closest('.lvhue').length) {
            u = 1;
        }
        if ($(e.target).closest('.enter_b').length) {
            u = 1;
        }
        if (!u) {
            $('.enter_b').fadeOut();
            $('.lvhue span').removeClass('open');
        }
    });


    // фильтр формы  (только числа)
    $('.pereh input, .ple input').keypress(function (event) {
        var key, keyChar;
        if (!event) var event = window.event;

        if (event.keyCode) key = event.keyCode;
        else if (event.which) key = event.which;

        if (key == null || key == 0 || key == 8 || key == 13 || key == 9 || key == 46 || key == 37 || key == 39) return true;
        keyChar = String.fromCharCode(key);

        if (!/\d/.test(keyChar))    return false;
    });
    var wid = $(window).width();

    if (wid < 500) {
        $('#carousel').carouFredSel(false);
        $('#carousel').carouFredSel({
            items: 2,
            //  direction           : "",
            prev: ".caroufredsel-prev",
            next: ".caroufredsel-next",
            scroll: {
                items: 2,
                duration: 1000,
                pauseOnHover: true
            }
        });
    }
    else {
        $('#carousel').carouFredSel(false);
        $('#carousel').carouFredSel({
            items: 5,
            //  direction           : "",
            prev: ".caroufredsel-prev",
            next: ".caroufredsel-next",
            scroll: {
                items: 5,
                duration: 1000,
                pauseOnHover: true
            }
        });
    }


    $('#carousel a').eq(0).addClass('act');

    $('#carousel a').click(function () {
        $('.fotkad').attr('src', $(this).attr('href'));
        $('.fotkad').parent('a').attr('href', $(this).attr('href'));
        $(this).addClass('act').siblings().removeClass('act');
        return false;
    });

    $('.for_lightbox a').colorbox({rel: 'gal', opacity: 0.8, current: " {current} из {total}", width: '1000px', maxWidth: '90%'});

    $('.a_fotkad').click(function () {
        $('.for_lightbox a').eq($('#carousel .act').index()).trigger('click');
        return false;
    });

    $('.analog').click(function () {
        if ($(this).hasClass('open')) {
            $('.tovar_analog').slideUp(); // закрытие
            //	$('.all_docum_text').slideDown();
            $(this).removeClass('open');
        } else {
            $('.tovar_analog').slideDown(); // открытие
            $('.all_docum_text').slideUp();
            $('.all_docum span').removeClass('open');
            $(this).addClass('open');
        }
    });

    $('.all_docum span').click(function () {
        if ($(this).hasClass('open')) {
            $('.all_docum_text').slideUp();
            //	$('.tovar_analog').slideDown();
            $(this).removeClass('open');
        } else {
            $('.all_docum_text').slideDown();
            $('.analog').removeClass('open');
            $('.tovar_analog').slideUp();
            $(this).addClass('open');
        }
    });

    $('.minus').click(function () {
        //var cart = $(this).closest('td').find('.skl').text();
        var inp = $(this).closest('.ple').find('input');
        if (inp.val() > 1) {
            inp.val(inp.val() * 1 - 1);
        }
        calc_cart();
        calc_weight();
        return false;
    });
    $('.plus').click(function () {
        var inp = $(this).closest('.ple').find('input');
        var skl = $(this).closest('td').find('.skl').text();
        var s21 = $(this).closest('tr').find('.s21').val();
        var s5 = $(this).closest('td').find('.s5').text();
        if (skl == "Под заказ") skl = 9999;
        //console.log(inp.val(), $(this).closest('td').find('.skl').text());
        if(s21 == '1'){
            skl = Math.floor(s5 * 1);
        }
        if ((inp.val() * 1) < (skl * 1)) {
            inp.val(inp.val() * 1 + 1);
        }
        calc_cart();
        calc_weight();
        return false;
    });

    $('.ple input').blur(function () {
        var skl = $(this).closest('td').find('.skl').text();
        var s21 = $(this).closest('tr').find('.s21').val();
        var s5 = $(this).closest('td').find('.s5').text();
        if (skl == "Под заказ") skl = 9999;
        if(s21 == '1'){
            skl = Math.floor(s5 * 1);
        }
        if (parseInt($(this).val()) > parseInt(skl)) {
            $(this).val(skl);
        }
        calc_cart();
        calc_weight();
    });

    $('.dost').click(function () {
        if ($(this).hasClass('checked')) {

            $('.hiddeg').show();
            var fhghg = 0;
            $('.bl2 span').each(function () {
                fhghg += $(this).html().replace(/\s*/g, '') * 1;
            });
            $('.bl6 span').html(fhghg);
            $('.bl6 span').text($('.bl6 span').text().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));

        } else {
            $('.hiddeg').hide();
            $('.bl6 span').html($('.bl2 span').eq(0).html());

        }
    });
    
    $('#sort').change(function () { 
         //$('#sort_form').attr('action',window.location.href);        
         //$('#sort_form').submit();  
         var sort = $('#sort').val();
         var query = window.location.search;
         query = query.replace('?','');
         var params = new URLSearchParams(query);
         params.set('sort',sort);        
         window.location.search=params;
         $('#sort_search').val(sort);
    });

    $('#availability').change(function () { 
        var query = window.location.search;        
        if(this.checked){  
            query = query.replace('?','');
            var params = new URLSearchParams(query);
            params.set('availability',$('#availability').val()); 
            $('#availability_search').val("on");   
        }else{     
            var params = new URLSearchParams(query);
            params=delPrm(query,'availability');
            $('#availability_search').val("");
        }      
        window.location.search=params;
    });
    
    function delPrm(Url,Prm) {
	    var a=Url.split('?');
	    var re = new RegExp('(\\?|&)'+Prm+'=[^&]+','g');
	    Url=('?'+a[1]).replace(re,'');
	    Url=Url.replace(/^&|\?/,'');
	    var dlm=(Url=='')? '': '?';
	    return a[0]+dlm+Url;
	};

    /*------------------------------------------------------------------------------------------------------*/


    /*-------------block 2----------------*/

    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block1');
        $('.bil_request').hide();
        var floooat = false;
        $("#cb2-styler.jq-radio").change(function () {
            console.log('1');

            if ($('#cb2-styler').hasClass('checked')) {
                console.log('checked');
                $('.bil_request').addClass("shw-block1").show().css('min-width', '108px');
                $('.ship_method').hide();
                $('.bil_request_lev5').removeClass("shw-block6").hide();
                /*	$('#cb1-styler').removeClass('checked');*/
            }
            else {
                $('.bil_request').removeClass('.shw-block1').hide();
                console.log('unchecked');
            }
        });
    });


    /*-------------block 1----------------*/

    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block2');
        $('.ship_method').hide();
        var form_open = false;
        $('#cb1-styler.jq-radio').change(function () {
            console.log('1');

            if ($('#cb1-styler').hasClass('checked')) {
                console.log('checked');
                $('.ship_method').addClass("shw-block2").show().css('min-width', '108px');
                $('.bil_request').hide();
                $('.bil_request_lev4').hide()

                /*$('#cb2-styler').removeClass('checked');*/

                $('.bil_request_lev2').removeClass('.shw-block3').hide();
                $('.bil_request_lev3').removeClass('.shw-block4').hide();
                $('.bil_request_lev5').removeClass("shw-block6").hide();
            }
            else {
                $('.ship_method').removeClass('.shw-block2').hide();
                console.log('unchecked');
            }
        });

    });

    /*-------------block 2.1----------------*/

    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block3');
        $('.bil_request_lev2').hide();
        $('.bil_request_lev4').hide();
        $('.bil_request_lev5').hide();
        var floooat = false;
        $('#business_line-styler.jq-radio').change(function () {
            if ($('#business_line-styler').hasClass('checked'))/*(!floooat)*/{
                $("#cb2-styler.jq-radio").addClass("checked");//добавляем класс checked для отображения радиокнопки уровнем выше
                $('.bil_request_lev3').removeClass('.shw-block4').hide();

                $('.bil_request_lev2').addClass("shw-block3").show().css('min-width', '108px');
                $('.bil_request_lev4').addClass("shw-block5").show().css('min-width', '108px');
                $('.bil_request_lev5').removeClass("shw-block6").hide().css('min-width', '108px');
                /*$('.bil_request').hide();*/
                /*floooat = true;*/
            } else {
                $('.bil_request_lev2').removeClass('.shw-block3').hide();
                $('.bil_request_lev4').removeClass('.shw-block5').hide();
            }
        });

    });

    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block4');
        $('.bil_request_lev2').hide();
        $('.bil_request_lev4').hide();
        $('.bil_request_lev5').hide();
        var floooat = false;
        $('#pec-styler.jq-radio').change(function () {
            if ($('#pec-styler').hasClass('checked'))/*(!floooat)*/{
                $("#cb2-styler.jq-radio").addClass("checked");//добавляем класс checked для отображения радиокнопки уровнем выше
                $('.bil_request_lev3').removeClass('.shw-block4').hide();

                $('.bil_request_lev2').addClass("shw-block3").show().css('min-width', '108px');
                $('.bil_request_lev4').removeClass("shw-block5").hide().css('min-width', '108px');
                $('.bil_request_lev5').addClass("shw-block6").show().css('min-width', '108px');
                /*$('.bil_request').hide();*/
                /*floooat = true;*/
            } else {
                $('.bil_request_lev2').removeClass('.shw-block3').hide();
                $('.bil_request_lev4').removeClass('.shw-block5').hide();
            }
        });

    });
    /*-------------block 2.2----------------*/

    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block4');
        $('.bil_request_lev3').hide();
        var floooat = false;
        $('#agree-styler.jq-radio').change(function () {
            if ($('#agree-styler').hasClass('checked')) {
                $("#cb2-styler.jq-radio").addClass("checked");//добавляем класс checked для отображения радиокнопки 2мя уровнями выше
                $('#business_line-styler').addClass('checked');//добавляем класс checked для отображения радиокнопки уровнем выше
                $('.bil_request_lev3').addClass("shw-block4").show().css('min-width', '108px');
            } else {
                $('.bil_request_lev3').removeClass('.shw-block4').hide();
            }
        });

    });
    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block4');
        $('.bil_request_lev3').hide();
        var floooat = false;
        $('#agr-styler.jq-radio').change(function () {
            if ($('#agr-styler').hasClass('checked')) {
                $("#cb2-styler.jq-radio").addClass("checked");//добавляем класс checked для отображения радиокнопки 2мя уровнями выше
                $('#pec-styler').addClass('checked');//добавляем класс checked для отображения радиокнопки уровнем выше
                $('.bil_request_lev3').addClass("shw-block4").show().css('min-width', '108px');
            } else {
                $('.bil_request_lev3').removeClass('.shw-block4').hide();
            }
        });

    });


    /*--------------Show checked when selecting the other buttons --------------------*/

    $(document).ready(function () {
        $('.personal tr').removeClass('shw-block1');
        $('.bil_request').hide();
        var floooat = false;
        $('#pickup-styler.jq-radio').change(function () {
            if ($('#pickup-styler').hasClass('checked')) {
                $('.bil_request_lev2').removeClass('.shw-block3').hide();
                $('.bil_request_lev4').removeClass('.shw-block5').hide();
                $("#cb2-styler.jq-radio").addClass("checked");//добавляем класс checked для отображения радиокнопки 2мя уровнями выше
                $('.bil_request_lev3').addClass("shw-block4").show().css('min-width', '108px');
                $('.bil_request_lev5').removeClass("shw-block6").hide();
            }
            else {
                $('.bil_request').removeClass('.shw-block1').hide();
                $('.bil_request_lev3').removeClass('.shw-block4').hide();
            }
        });

    });
    /*------------------------------------------------------------------------------------------------------*/


    $('.close_modal').click(function () {
        $(this).closest('.modal').animate({
            top: $(this).closest('.modal').innerHeight() * (-1) + 'px'
        }, 500);
        return false;
    });

    $('.registration').click(function () {
        var form = $(this).closest('.personal');
        var form_text = form.find('input[type="text"]');
        var form_email = form.find('input[type="email"]');
        var form_pass = form.find('input[type="password"]');
        var fio = form.find('input[name="fio"]').val();
        var tel = form.find('input[name="tel"]').val();
        var email = form.find('input[name="email"]').val();
        var address;
        var pass = form.find('input[name="password"]').val();
        var conf_pass = form.find('input[name="confirm_password"]').val();
        var textarea = form.find('textarea');
        var err = 0;
        form.find('input').removeClass('error');
        form.find('input').removeClass('textarea');
        //	console.log($(this).closest('.personal'));
        form_text.each(function () {
            if ($(this).attr('name') == "siteusername") {
                $(this).addClass('no_border_col');
            } else if ($(this).val() == "") {
                if ($(this).attr('name') === 'inn' || $(this).attr('name') === 'kpp') {
                }
                else {                    
                    err = 1;
                    $(this).addClass('error');
                }
            }
        });
        form_pass.each(function () {

            if ($(this).val() == "") {
                err = 1;
                $(this).addClass('error');
            }
        });
        textarea.each(function () {
            address = $(this).val().toString();
            if (address == "") {
                err = 1;
                $(this).addClass('error');
            }
        });
        form_email.each(function () {
            if (!isEmail($(this).val())) {
                err = 1;
                $(this).addClass('error');
            }
        });
        if (fio == "") {
            err = 1;
            alert("Вы не заполнили поле ФИО");
        } else if (tel == "") {
            err = 1;
            alert("Вы не заполнили поле Телефон");
        } else if (email == "") {
            err = 1;
            alert("Вы не заполнили поле Эл. почта");
        } else if (address == "") {
            err = 1;
            alert("Вы не заполнили поле Адрес");
        } else if (pass.toString().length < 5 || conf_pass.toString().length < 5) {
            err = 1;
            alert("Длина пароля минимум 5 символов");
        } else if (pass !== conf_pass) {
            err = 1;
            alert("Вы некорректно подтвердили пароль");
        }
        if (err == 1) {

            return false;
        }
    });


});

function calc_cart() {
    var summ = 0;
    var sum_temp;
    var dol = $('.cart').attr('rel');
    $('.s12').each(function () {
        //console.log($(this).html()); replace(' ', '');
        sum_temp = parseFloat($(this).html().replace(/[,]+/g, '.').replace(' ', '')) * $(this).closest('tr').find('.ple input').val();
       // console.log($(this).closest('tr').find('.s21').html().replace(/[,]+/g, '.').replace(' ', ''));
        if(parseFloat($(this).closest('tr').find('.s21').val().replace(/[,]+/g, '.').replace(' ', '')) > 0){
            sum_temp = sum_temp / parseFloat($(this).closest('tr').find('.s5').html().replace(/[,]+/g, '.').replace(' ', '')) + parseFloat($(this).closest('tr').find('.s21').val().replace(/[,]+/g, '.').replace(' ', '')) * parseFloat($("input[name='eur_cur']").val());;
            //console.log(parseFloat($(this).closest('tr').find('.s5').html().replace(/[,]+/g, '.').replace(' ', '')), parseFloat($(this).closest('tr').find('.s21').val().replace(/[,]+/g, '.').replace(' ', '')), parseFloat($("input[name='eur_cur']").val()));
        }
        //console.log(parseFloat($(this).html()),$(this).html(),sum_temp);
        $(this).closest('tr').find('.s2').html(sum_temp.toFixed(2).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
        $(this).closest('tr').find('.s3').html((sum_temp / dol).toFixed(2).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 '));
        summ += sum_temp;
    });

    if ($('.percent').text() != '') {
        summ = summ * (100 - $('.percent').text()) / 100;
    }
    $('.bl6 span').text(summ.toFixed(2).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ') + ' руб.');
    /*
     if(summ<10000){
     $('.dostt').show();
     $('.bl6 span').text((summ+500).toFixed(2).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ')+' руб.');
     } else {
     $('.dostt').hide();
     $('.bl6 span').text(summ.toFixed(2).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ')+' руб.');
     }
     */
}
function calc_weight() {
    var summ = 0;
    var sum_temp;
    $('.s4').each(function () {
        sum_temp = $(this).html() * $(this).closest('tr').find('.ple input').val();
        $(this).closest('tr').find('.s4_all').html(sum_temp.toFixed(5));
        summ += sum_temp;
    });
    $('.weight').html(summ.toFixed(5));
}

function isEmail(sEmail) {
    var sEmail = sEmail.replace(new RegExp('/\(.*?\)/'), '');
    var oRegExp = /^[A-Za-z0-9][-\w]*(\.[A-Za-z0-9][-\w]*)*@[A-Za-z0-9][-\w]*(\.[A-Za-z0-9][-\w]*)*\.[a-zA-Z]{2,4}$/;
    return oRegExp.test(sEmail);
}
$(document).ready(function () {
    var $headScroll = $('.header_scroll');
    $headScroll.removeClass('header_mini');
    $headScroll.parent().removeAttr('id');
    $("#goup .header_mini").hide().removeAttr("href");
    var $headMinGoUp = $("#goup .header_mini");
    var headMin = 'header_mini';
    var wid = $(window).width();

    if (wid > 768) {

        if ($(window).scrollTop() >= "44") {
            $headMinGoUp.fadeIn(10);
            $headScroll.addClass(headMin);
            $headScroll.parent().attr('id', 'goup');
        }
    }
    else {
        $headScroll.removeClass(headMin);
        $headScroll.parent().removeAttr('id');
        $headMinGoUp.fadeOut(10);
    }

    $(window).scroll(function () {
        if (wid > 768) {
            if ($(window).scrollTop() <= "44") {
                $headScroll.removeClass(headMin);
                $headScroll.parent().removeAttr('id');
                $headMinGoUp.fadeOut(10);
            } else {
                $headMinGoUp.fadeIn(10);
                $headScroll.addClass(headMin);
                $headScroll.parent().attr('id', 'goup');
            }
        }
        else {
            $headScroll.removeClass(headMin);
            $headScroll.parent().removeAttr('id');
            $headMinGoUp.fadeOut(10);
        }
    });
    $('.mm_sold_select').change(function (eventObject) {
        var val_sel = parseInt($(".mm_sold_select option:selected").val());
        var count = parseInt($("#pr_count").val());
        var dlina = parseFloat($("#pr_dlina").val());
        var dlina_v = parseFloat($(".qty_form").val());
        var price_sht1 = parseFloat($(".tglf3 .newp").text().replace(/\s+/g, ''));
        var price_sht = parseFloat($("input[name='price_sht']").val());
        var mm_coef = parseFloat($("#pr_mm_coef").val());
        var qty = parseFloat($("input[name='qty']").val());
        var tglf2 = $(".tglf2").text();
        tglf2 = $.trim(tglf2);

        if (price_sht == 0) {
            price_sht = price_sht1;
            $("input[name='price_sht']").val(price_sht);
        }

        if (val_sel == 0) {
            dlina_v = parseInt(dlina_v);
            if (dlina_v > count) {
                $("input[name='qty']").val(count);                
                alert('Нельзя заказать более' + count + 'шт.' );
                $(".tglf3 .newp").text(String((price_sht * count).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');
            } else {
                $("input[name='qty']").val(dlina_v);
                $(".tglf3 .newp").text(String((price_sht * dlina_v).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');
            }
            if (tglf2 != 'Под заказ') {
                $(".tglf2 span").text(count + ' шт');
            }

        } else {
            if (dlina_v > dlina) {
                $("input[name='qty']").val(Math.floor(dlina));
                
                alert('Нельзя заказать более' + count + 'шт.' );
                $(".tglf3 .newp").text(String((price_sht).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');
            }else{
                $(".tglf3 .newp").text(String((price_sht / dlina * dlina_v + mm_coef).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');
            }
            if (tglf2 != 'Под заказ') {
                $(".tglf2 span").text(count * dlina + ' мм');
            }

        }

    });
    $('.qty_form').change(function (eventObject) {
        var val_sel = parseInt($(".mm_sold_select option:selected").val());
        var dlina = parseFloat($("#pr_dlina").val());
        var count = parseInt($("#pr_count").val());
        var dlina_v = parseFloat($(".qty_form").val());
        var tglf2 = $(".tglf2").text();
        var price_sht = parseFloat($("input[name='price_sht']").val());
        var mm_coef = parseFloat($("#pr_mm_coef").val());
        tglf2 = $.trim(tglf2);

        dlina = Math.floor(dlina);
        if (val_sel == 1) {

            if (dlina_v > dlina) {

                $("input[name='qty']").val(dlina);
                $(".tglf3 .newp").text(String((price_sht).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');

                alert('В данный момент в наличии: ' + dlina + ' м.');
            }else{
                $(".tglf3 .newp").text(String((price_sht / dlina * dlina_v + mm_coef).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');

            }

        } else {
            if (tglf2 != 'Под заказ') {
                dlina_v = parseInt(dlina_v);
                if (dlina_v > count) {
                    $(".tglf3 .newp").text(String((price_sht * count).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');
                    $("input[name='qty']").val(count);
                    alert('В данный момент в наличии: ' + count + ' шт.');
                } else {
                    $("input[name='qty']").val(dlina_v);
                    $(".tglf3 .newp").text(String((price_sht * dlina_v).toFixed(2)).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1 ") + ' руб.');
                }
            }
        }

    });


    return false;
});

$(function () {
    $('.big-slider').slick({
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        speed: 1000,
        autoplay: true,
        autoplaySpeed: 3000,
        
/*смена стандартной анимации слайдера*/
        infinite: true,
        speed: 1000,
        fade: true,
        autoplaySpeed: 2000,
        cssEase: 'linear'
    });
    $('.mini-slider-company').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
              }
            }

          ]
    });
});



$(function () {
    var $leftMenuLink = $('.left_menu_accordeon>li>a');
    var actHow = 'activ_hov';
    var $leftSubMenu = $('.left_menu_accordeon>li>ul');

    /*$leftMenuLink.attr('href', '#');*/
    var $activeItem = $('.left_menu_accordeon li ul li.act');
    if ($activeItem.length) {
        $activeItem.parent().slideDown(500).parent().addClass(actHow);
    };
/*
    $leftMenuLink.on('click', function () {
        var $this = $(this);
        var $thisNext = $(this).next();
        var $thisParent = $this.parent();

        if ($thisParent.hasClass(actHow)) {
            $thisParent.removeClass(actHow);
            $thisNext.slideUp(500);
        } else {
            $('.left_menu_accordeon li').removeClass(actHow);
            $('.left_menu_accordeon li ul').slideUp(500);
            $thisParent.toggleClass(actHow);
            $thisNext.slideToggle(500);
        }
    });
    */
});


var $showMenuList = $('.show-cont-list-menu');
$showMenuList.hover(function(){
    $(this).find('.cont-dropdown-block').animate({top: '0'},{queue:false,duration:500});
    $(this).find('.dropdown-block').css({'display': 'block'});
    $(this).find('object').css({'display': 'block'});
},function(){
    $(this).find('.cont-dropdown-block').animate({top: '210px'},{queue:false,duration:500});
    $(this).find('.dropdown-block').css({'display': 'none'});
    $(this).find('object').css({'display': 'none'});
});





$(window).on('load', function() {
    menu();
    sidemenu();
    $('.touch-menu').on('click', function(e) {
        e.preventDefault();
        $('nav').slideToggle();
    });
    $('.touch-sidemenu').on('click', function(e) {
        e.preventDefault();
        $('.left_menu_accordeon').slideToggle();
    });
});
$(window).on('resize', function() {
    menu();
    sidemenu();
});


function menu() {
    var wid = $(window).width();
    if( wid > 1430) {
        $('nav').show();

    }
    else {
        $('nav').hide();

    }
}
function sidemenu() {
    var wid = $(window).width();
    if( wid > 992) {
        $('.left_menu_accordeon').show();

    }
    else {
        $('.left_menu_accordeon').hide();

    }
};